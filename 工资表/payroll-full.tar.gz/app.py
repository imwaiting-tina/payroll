"""📊 总看板 — HRO 开弈集团"""

import streamlit as st
import pandas as pd
from utils.auth import check_login, render_sidebar, FULL_ACCESS_ROLES
from utils.data_loader import load_salary_data, get_available_months
from utils.summary_engine import compute_summary
from utils.importer import decrypt_excel, extract_salary_from_excel, save_salary_data

st.set_page_config(page_title="HRO 总看板", page_icon="▣", layout="wide")
check_login()
render_sidebar()

# ── 月份选择器 + 标题同行 ──
available = get_available_months()
month_labels = [label for _, _, label in available]
cur_label = st.session_state.get("current_month", month_labels[0] if month_labels else "2026年6月")
try:
    default_idx = month_labels.index(cur_label)
except:
    default_idx = 0

col_t, col_m, col_s = st.columns([1.5, 1, 6])
with col_t:
    st.markdown('<p style="font-size:1.2rem;font-weight:700;color:#1E293B;margin:0;white-space:nowrap;">📊 总看板</p>',
                unsafe_allow_html=True)
with col_m:
    if month_labels:
        sel = st.selectbox("", month_labels, index=default_idx, key="dashboard_month",
                           label_visibility="collapsed")
        st.session_state.current_month = sel
        idx = month_labels.index(sel)
        year, month, _ = available[idx]
    else:
        year, month = 2026, 6

st.caption(f"HRO 开弈集团 · FY{year}年{month}月")
st.divider()

if st.session_state.role not in FULL_ACCESS_ROLES:
    st.info("👋 员工身份仅可查看本人工资。请使用左侧导航进入「薪酬明细」。")
    st.stop()

df = load_salary_data(year, month)
summary = compute_summary(df)
gt = summary['grand_total']

# ── KPI 卡片 ──
c1, c2, c3, c4, c5 = st.columns(5)
c1.metric("🏢 企业总成本", f"¥{gt['企业人力成本总计']:,.0f}")
c2.metric("💵 实收工资", f"¥{gt['实收']:,.0f}")
c3.metric("🧾 个人所得税", f"¥{gt['当月个人所得税']:,.0f}")
c4.metric("🏥 社保(公司)", f"¥{gt['公司法定福利合计']:,.0f}")
c5.metric("👥 总人数", f"{gt['人数']} 人")

st.divider()

# ── 双栏汇总 ──
cl, cr = st.columns(2)
with cl:
    st.markdown('<p style="font-weight:600;color:#1E293B;margin-bottom:6px;">🏢 按板块（成本中心 BU）</p>',
                unsafe_allow_html=True)
    bd = summary['by_board_detail'][['板块','成本中心（P&L核算标准）',
        '企业人力成本总计','实收','当月个人所得税','公司法定福利合计','个人福利合计','人数']].copy()
    bt = pd.DataFrame([{
        '板块':'总计','成本中心（P&L核算标准）':'—',
        '企业人力成本总计':gt['企业人力成本总计'],'实收':gt.get('实收',0),
        '当月个人所得税':gt.get('当月个人所得税',0),'公司法定福利合计':gt.get('公司法定福利合计',0),
        '个人福利合计':gt.get('个人福利合计',0),'人数':int(gt['人数'])
    }])
    st.dataframe(pd.concat([bd,bt],ignore_index=True).fillna('—'),
                 use_container_width=True,hide_index=True,height=420)
with cr:
    st.markdown('<p style="font-weight:600;color:#1E293B;margin-bottom:6px;">🏦 按发薪公司</p>',
                unsafe_allow_html=True)
    pd_ = summary['by_payroll_detail'][['发薪公司系','发薪公司',
        '企业人力成本总计','实收','当月个人所得税','公司法定福利合计','个人福利合计','人数']].copy()
    pt = pd.DataFrame([{
        '发薪公司系':'总计','发薪公司':'—',
        '企业人力成本总计':gt['企业人力成本总计'],'实收':gt.get('实收',0),
        '当月个人所得税':gt.get('当月个人所得税',0),'公司法定福利合计':gt.get('公司法定福利合计',0),
        '个人福利合计':gt.get('个人福利合计',0),'人数':int(gt['人数'])
    }])
    st.dataframe(pd.concat([pd_,pt],ignore_index=True).fillna('—'),
                 use_container_width=True,hide_index=True,height=420)

st.divider()

# ── 导入区 ──
if st.session_state.role in FULL_ACCESS_ROLES:
    with st.expander("📥 导入工资数据", expanded=False):
        up_col, pw_col, btn_col = st.columns([3, 2, 1.5])
        with up_col:
            uploaded = st.file_uploader("上传加密 Excel", type=["xlsx"],
                                         key="import_up", label_visibility="collapsed")
        with pw_col:
            pwd = st.text_input("密码", type="password", placeholder="文件密码",
                                key="import_pw", label_visibility="collapsed")
        with btn_col:
            if uploaded and pwd:
                if st.button("🔓 解密导入", type="primary", use_container_width=True, key="import_go"):
                    try:
                        decrypted = decrypt_excel(uploaded.getvalue(), pwd)
                        dff = extract_salary_from_excel(decrypted)
                        save_salary_data(dff, year, month)
                        st.cache_data.clear()
                        st.success(f"✅ 导入成功！{len(dff)} 条")
                        st.rerun()
                    except Exception as e:
                        msg = str(e)
                        if "password" in msg.lower() or "密码" in msg:
                            st.error("🔒 密码错误")
                        elif "找不到" in msg:
                            st.error(f"❌ {msg}")
                        else:
                            st.error(f"❌ {msg}")
