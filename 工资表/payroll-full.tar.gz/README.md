# 薪资管理系统

开弈集团薪资管理平台 — 基于 Streamlit 的在线薪酬数据展示与管理系统。

## 功能

- 🔐 多角色权限登录（管理员/人事/员工）
- 💰 薪酬明细数据展示与搜索
- 🏥 社保/公积金明细数据展示
- 📊 按部门、公司等维度筛选
- 📥 数据导出为 CSV

## 测试账号

| 用户名 | 密码 | 角色 | 权限 |
|--------|------|------|------|
| admin | admin123 | 管理员 | 查看全部数据 |
| hr | hr123 | 人事专员 | 查看全部数据 |
| employee | emp123 | 普通员工 | 仅查看本人数据 |

## 本地运行

```bash
pip install -r requirements.txt
streamlit run app.py
```

## 部署到 Streamlit Cloud

1. 将代码推送到 GitHub 私有仓库
2. 在 [Streamlit Cloud](https://streamlit.io/cloud) 连接 GitHub 仓库
3. 数据文件放在 `data/` 目录下
4. 部署即可

## 目录结构

```
payroll-app/
├── app.py                  # 主入口（首页仪表盘）
├── pages/
│   ├── 1_💰_薪酬明细.py    # 薪酬明细页面
│   └── 2_🏥_社保明细.py    # 社保明细页面
├── utils/
│   ├── auth.py             # 认证与权限模块
│   └── data_loader.py      # 数据加载模块
├── data/
│   ├── 薪酬明细.csv         # 薪酬数据（不提交到 Git）
│   └── HR社保明细.csv       # 社保数据（不提交到 Git）
├── requirements.txt
└── README.md
```
