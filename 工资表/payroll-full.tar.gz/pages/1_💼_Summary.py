"""💼 Summary"""

import streamlit as st
import pandas as pd
from utils.auth import check_login, render_sidebar, FULL_ACCESS_ROLES
from utils.data_loader import load_salary_data, get_available_months
from utils.summary_engine import compute_summary
from utils.exporter import export_summary_to_excel

st.set_page_config(page_title="Summary · HRO", page_icon="💼", layout="wide")
check_login()
render_sidebar()

available = get_available_months()
labels = [l for _, _, l in available]
cur = st.session_state.get("current_month", labels[0] if labels else "2026年6月")
idx = labels.index(cur) if cur in labels else 0

ct, cm, cs = st.columns([1.2, 1, 6])
with ct:
    st.markdown('<p style="font-size:1.2rem;font-weight:700;color:#1E293B;margin:0;">💼 Summary</p>',
                unsafe_allow_html=True)
with cm:
    sel = st.selectbox("", labels, index=idx, key="summary_m", label_visibility="collapsed")
st.session_state.current_month = sel
i = labels.index(sel)
y, m, _ = available[i]
st.caption(f"按成本中心(BU) / 按发薪公司 — FY{y}年{m}月")
st.divider()

if st.session_state.role not in FULL_ACCESS_ROLES:
    st.warning("无权限"); st.stop()

df = load_salary_data(y, m)
s = compute_summary(df)
gt = s['grand_total']

# Block 1
st.subheader("▎按成本中心（BU）")
r1 = []
for _, r in s['by_board_detail'].iterrows():
    r1.append([r['板块'], r['成本中心（P&L核算标准）'] or '—',
               r.get('企业人力成本总计',0), int(r.get('人数',0)),
               r.get('实收',0), r.get('当月个人所得税',0),
               r.get('公司法定福利合计',0), r.get('个人福利合计',0),
               r.get('绩效&佣金合计',0), r.get('考勤调整',0),
               r.get('商保金额',0), r.get('预提福利费',0)])
r1.append(['总计','—',gt['企业人力成本总计'],gt['人数'],
           gt.get('实收',0),gt.get('当月个人所得税',0),
           gt.get('公司法定福利合计',0),gt.get('个人福利合计',0),
           gt.get('绩效&佣金合计',0),gt.get('考勤调整',0),
           gt.get('商保金额',0),gt.get('预提福利费',0)])
df1 = pd.DataFrame(r1, columns=['板块','成本中心(BU)','企业成本','人数','实收工资',
                                 '个税','社保(公司)','社保(个人)','绩效&佣金','考勤调整','商业保险','预提福利费'])
st.dataframe(df1.fillna('—'), use_container_width=True, hide_index=True, height=640)

# Block 2
st.subheader("▎按发薪公司")
r2 = []
for _, r in s['by_payroll_detail'].iterrows():
    r2.append([r['发薪公司系'], r['发薪公司'] or '—',
               r.get('企业人力成本总计',0), int(r.get('人数',0)),
               r.get('实收',0), r.get('当月个人所得税',0),
               r.get('公司法定福利合计',0), r.get('个人福利合计',0),
               r.get('绩效&佣金合计',0), r.get('考勤调整',0),
               r.get('商保金额',0), r.get('预提福利费',0)])
r2.append(['总计','—',gt['企业人力成本总计'],gt['人数'],
           gt.get('实收',0),gt.get('当月个人所得税',0),
           gt.get('公司法定福利合计',0),gt.get('个人福利合计',0),
           gt.get('绩效&佣金合计',0),gt.get('考勤调整',0),
           gt.get('商保金额',0),gt.get('预提福利费',0)])
df2 = pd.DataFrame(r2, columns=['发薪公司系','发薪公司','企业成本','人数','实收工资',
                                 '个税','社保(公司)','社保(个人)','绩效&佣金','考勤调整','商业保险','预提福利费'])
st.dataframe(df2.fillna('—'), use_container_width=True, hide_index=True, height=640)

# 导出
st.divider()
xlsx_s = export_summary_to_excel(s['by_board'], s['by_payroll'], s['grand_total'])
st.download_button("📥 Excel", xlsx_s, "Summary.xlsx",
                   "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                   use_container_width=True)
