"""💰 薪酬明细"""

import streamlit as st
import pandas as pd
from utils.auth import check_login, render_sidebar, filter_data_by_role, FULL_ACCESS_ROLES
from utils.data_loader import load_salary_data, get_available_months
from utils.exporter import export_to_excel

st.set_page_config(page_title="薪酬明细 · HRO", page_icon="💰", layout="wide")
check_login()
render_sidebar()

available = get_available_months()
labels = [l for _, _, l in available]
cur = st.session_state.get("current_month", labels[0] if labels else "2026年6月")
idx = labels.index(cur) if cur in labels else 0

ct, cm, cs = st.columns([1.4, 1, 6])
with ct:
    st.markdown('<p style="font-size:1.2rem;font-weight:700;color:#1E293B;margin:0;">💰 薪酬明细</p>',
                unsafe_allow_html=True)
with cm:
    sel = st.selectbox("", labels, index=idx, key="salary_m", label_visibility="collapsed")
st.session_state.current_month = sel
i = labels.index(sel)
y, m, _ = available[i]
st.caption(f"FY{y}年{m}月 · 员工薪酬完整数据")
st.divider()

df_all = load_salary_data(y, m)
original = len(df_all)
df = filter_data_by_role(df_all)

# 筛选
c1, c2, c3, c4 = st.columns(4)
with c1:
    kw = st.text_input("🔍 姓名", placeholder="搜索")
with c2:
    opts = ["全部"] + sorted(df["发薪公司"].dropna().unique().tolist()) if "发薪公司" in df.columns else ["全部"]
    comp = st.selectbox("🏢 发薪公司", opts)
with c3:
    opts = ["全部"] + sorted(df["部门"].dropna().unique().tolist()) if "部门" in df.columns else ["全部"]
    dept = st.selectbox("📂 部门", opts)
with c4:
    opts = ["全部"] + sorted(df["人员性质"].dropna().unique().tolist()) if "人员性质" in df.columns else ["全部"]
    ptype = st.selectbox("👤 人员性质", opts)

if kw: df = df[df["姓名"].astype(str).str.contains(kw, na=False)]
if comp and comp != "全部": df = df[df["发薪公司"] == comp]
if dept and dept != "全部": df = df[df["部门"] == dept]
if ptype and ptype != "全部": df = df[df["人员性质"] == ptype]

stotal = pd.to_numeric(df["实收"], errors="coerce").sum()
ctotal = pd.to_numeric(df["企业人力成本总计"], errors="coerce").sum()
taxtotal = pd.to_numeric(df["当月个人所得税"], errors="coerce").sum()
c1, c2, c3, c4 = st.columns(4)
c1.metric("员工数", f"{len(df)} 人")
c2.metric("实收合计", f"¥{stotal:,.0f}")
c3.metric("个税合计", f"¥{taxtotal:,.0f}")
c4.metric("企业总成本", f"¥{ctotal:,.0f}")

st.divider()
st.dataframe(df.fillna('—'), use_container_width=True, height=620, hide_index=True)

# 导出
if st.session_state.role in FULL_ACCESS_ROLES:
    st.divider()
    e1, e2, e3 = st.columns([1, 1, 5])
    with e1:
        st.download_button("📥 CSV", df.to_csv(index=False).encode("utf-8-sig"),
                           "薪酬明细.csv", "text/csv", use_container_width=True)
    with e2:
        st.download_button("📥 Excel", export_to_excel(df),
                           "薪酬明细.xlsx",
                           "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                           use_container_width=True)

st.caption(f"共 {len(df)} 条" + (f"（过滤自 {original} 条）" if original != len(df) else ""))
