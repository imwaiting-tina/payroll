"""导入模块 — 按名称匹配提取，兼容6月/7月列布局"""

import io
import pandas as pd
import msoffcrypto
import openpyxl
from pathlib import Path
from collections import defaultdict

NEW_HEADERS = [
    '发薪公司验证数据','成本中心（P&L核算标准）','发薪公司','人员性质','部门',
    '汇报人','职位','所属人','姓名','考勤制','本月变化类型','变化备注',
    '企业人力成本总计','实收','计税月份','基本工资','补贴/补充公积金','考勤调整',
    '其他补贴/调整','商保金额','本月工资调整','KPI预提','本月工资',
    '商办佣金','绩效','公寓佣金','防暑降温费','津贴','保安奖金','保洁奖金',
    '薪资小计','社保公积金缴纳月份','社保基数','公积金基数','养老(个人)',
    '医疗(个人)','失业(个人)','公积金(个人)','补充公积金(个人)','个人福利合计',
    '当月个人所得税','商保调整','银行实发','养老(公司)','医疗(公司)','失业(公司)',
    '工伤','生育','公积金(公司)','补充公积金(公司)','公司法定福利合计',
    '绩效&佣金合计','预提福利费',
]

_CHECK_MARKERS = ['验算', '合计', '核对']

# Fields that map 1:1 by name
DIRECT_NAMES = [
    '发薪公司验证数据','成本中心（P&L核算标准）','发薪公司','人员性质','部门',
    '汇报人','职位','所属人','姓名','考勤制','本月变化类型','变化备注',
    '企业人力成本总计','实收','计税月份','基本工资','补贴/补充公积金','考勤调整',
    '其他补贴/调整','商保金额','本月工资调整','KPI预提','本月工资',
    '商办佣金','绩效','公寓佣金','防暑降温费','津贴','保安奖金','保洁奖金',
    '薪资小计','社保基数','公积金基数','个人福利合计',
    '当月个人所得税','商保调整','银行实发',
    '工伤','生育','公司法定福利合计','绩效&佣金合计','预提福利费',
]

# Special: 社保公积金缴纳月份 (has space variant)
# Personal: 养老/医疗/失业/公积金/补充公积金 → first occurrence
# Company: 养老/医疗/失业/公积金/补充公积金 → second occurrence
PERSONAL_NAMES = ['养老', '医疗', '失业', '公积金', '补充公积金']
COMPANY_NAMES  = ['养老', '医疗', '失业', '公积金', '补充公积金']


def decrypt_excel(file_bytes: bytes, password: str) -> bytes:
    f = io.BytesIO(file_bytes)
    office_file = msoffcrypto.OfficeFile(f)
    office_file.load_key(password=password)
    decrypted = io.BytesIO()
    office_file.decrypt(decrypted)
    decrypted.seek(0)
    return decrypted.getvalue()


def _find_col(header_map, target):
    """Exact match first, then substring"""
    for ci, name in header_map.items():
        if name == target:
            return ci
    for ci, name in header_map.items():
        if target in name:
            return ci
    return 0


def extract_salary_from_excel(excel_bytes: bytes) -> pd.DataFrame:
    wb = openpyxl.load_workbook(io.BytesIO(excel_bytes), data_only=True)

    sheet_name = '薪酬明细'
    if sheet_name not in wb.sheetnames:
        candidates = [s for s in wb.sheetnames if '薪酬' in s or '薪资' in s]
        if candidates: sheet_name = candidates[0]
        else: raise ValueError(f"找不到'薪酬明细'，可用: {wb.sheetnames}")

    ws = wb[sheet_name]

    # ── 读表头 ──
    header_map = {}
    for col in range(1, ws.max_column + 1):
        v = ws.cell(row=9, column=col).value
        if v: header_map[col] = str(v).replace('\n', ' ').strip()

    # 记录每个名称出现的顺序
    name_positions = defaultdict(list)
    for ci in sorted(header_map.keys()):
        name_positions[header_map[ci]].append(ci)

    def first_occ(name):
        return name_positions.get(name, [0])[0]

    def second_occ(name):
        pos = name_positions.get(name, [])
        return pos[1] if len(pos) > 1 else 0

    # ── 构建映射：output_index → excel_column ──
    mapping = {}

    for name in DIRECT_NAMES:
        idx = NEW_HEADERS.index(name)
        mapping[idx] = _find_col(header_map, name)

    # 社保公积金缴纳月份
    mapping[NEW_HEADERS.index('社保公积金缴纳月份')] = (
        _find_col(header_map, '社保公积金 缴纳月份') or
        _find_col(header_map, '社保公积金缴纳月份')
    )

    # 个人社保：第一次出现
    for name in PERSONAL_NAMES:
        idx = NEW_HEADERS.index(f'{name}(个人)')
        mapping[idx] = first_occ(name)

    # 公司社保：第二次出现
    for name in COMPANY_NAMES:
        idx = NEW_HEADERS.index(f'{name}(公司)')
        mapping[idx] = second_occ(name)

    # ── 提取数据 ──
    data_rows = []
    for row_idx in range(10, ws.max_row + 1):
        new_row = [''] * 53
        val9 = ws.cell(row=row_idx, column=9).value
        has_data = False

        for new_col, excel_col in mapping.items():
            if not excel_col:
                continue
            val = ws.cell(row=row_idx, column=excel_col).value
            if val is not None:
                new_row[new_col] = val
                if new_col <= 9:
                    has_data = True

        if not has_data:
            continue

        name = str(val9).strip() if val9 else ''
        if not name or any(m in name for m in _CHECK_MARKERS):
            continue

        data_rows.append(new_row)

    if not data_rows:
        raise ValueError("未提取到有效数据")

    return pd.DataFrame(data_rows, columns=NEW_HEADERS)


def save_salary_data(df: pd.DataFrame, year: int, month: int, data_dir: str = None):
    if data_dir is None:
        data_dir = Path(__file__).parent.parent / "data"
    else:
        data_dir = Path(data_dir)
    data_dir.mkdir(parents=True, exist_ok=True)

    fname = f"薪酬明细_{year}{month:02d}.csv"
    csv_path = data_dir / fname
    df.to_csv(csv_path, index=False, encoding='utf-8-sig')

    latest_link = data_dir / "薪酬明细.csv"
    with open(latest_link, 'w', encoding='utf-8-sig') as f:
        f.write(fname)
    return str(csv_path)


def list_available_months(data_dir: str = None) -> list:
    if data_dir is None:
        data_dir = Path(__file__).parent.parent / "data"
    else:
        data_dir = Path(data_dir)

    months = []
    for f in sorted(data_dir.glob("薪酬明细_*.csv"), reverse=True):
        name = f.stem
        parts = name.split('_')
        if len(parts) >= 2 and len(parts[-1]) == 6:
            yyyymm = parts[-1]
            y, m = int(yyyymm[:4]), int(yyyymm[4:])
            months.append((y, m, f.name))
    return months
