"""数据加载模块 — 多月份支持"""

import streamlit as st
import pandas as pd
from pathlib import Path
from utils.importer import list_available_months

ROOTS = [
    Path("/mount/src/payroll-system/data"),
    Path(__file__).parent.parent / "data",
    Path.cwd() / "data",
]

_CHECK_MARKERS = ['验算', '合计', '核对']


def _find_data_dir() -> Path:
    for root in ROOTS:
        if root.exists():
            return root
    return Path(__file__).parent.parent / "data"


def get_available_months() -> list:
    """[(year, month, '2026年6月'), ...]"""
    data_dir = _find_data_dir()
    months = list_available_months(str(data_dir))
    return [(y, m, f"{y}年{m}月") for y, m, _ in months]


def _read_file(filepath: Path) -> pd.DataFrame:
    """读取CSV，自动去核对行，并格式化数字"""
    df = pd.read_csv(filepath)
    mask_bad = (
        df['姓名'].isna() |
        (df['姓名'].astype(str).str.strip() == '') |
        df['姓名'].astype(str).str.contains('|'.join(_CHECK_MARKERS), na=False)
    )
    df = df[~mask_bad]
    if '发薪公司验证数据' in df.columns:
        df = df.dropna(subset=['发薪公司验证数据'])
        df = df[~df['发薪公司验证数据'].astype(str).str.contains('|'.join(_CHECK_MARKERS), na=False)]
        df = df[df['发薪公司验证数据'].astype(str).str.strip() != '']

    # 3. 格式化整数列
    for col in ['计税月份', '社保公积金缴纳月份']:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0).astype(int)

    # 4. 替换所有 None/NaN/0 → "—" （兼容 Streamlit 渲染）
    df = df.fillna('—')
    # 把数字 0 也换成 —
    num_cols = df.select_dtypes(include=['float64', 'int64']).columns
    for c in num_cols:
        df[c] = df[c].apply(lambda x: '—' if x == 0 else x)

    return df


@st.cache_data
def load_salary_data(year: int = None, month: int = None) -> pd.DataFrame:
    """加载指定月份数据，默认最新"""
    data_dir = _find_data_dir()

    if year is not None and month is not None:
        path = data_dir / f"薪酬明细_{year}{month:02d}.csv"
        if path.exists():
            return _read_file(path)

    # 尝试读取 default 指针
    default = data_dir / "薪酬明细.csv"
    if default.exists():
        content = default.read_text(encoding='utf-8-sig').strip()
        if content.endswith('.csv'):
            target = data_dir / content
            if target.exists():
                return _read_file(target)

    # 回退：找最新的月份文件
    months = list_available_months(str(data_dir))
    if months:
        _, _, fname = months[0]
        return _read_file(data_dir / fname)

    raise FileNotFoundError(f"在 {data_dir} 中找不到任何薪酬数据文件")
