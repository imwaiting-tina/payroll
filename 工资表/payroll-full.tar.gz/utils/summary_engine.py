"""Summary 引擎 — 从薪酬明细实时计算汇总（自动去除核对行）"""

import pandas as pd
import numpy as np

# ── 成本中心(BU) → 板块 映射表 ──────────
CC_TO_BOARD = {
    'G-集团管理层': '集团IIT', 'G-Jenny-家庭': '集团IIT', 'G-香港办': '集团IIT',
    'G-管培生': '集团IIT', 'G-时代人才': '集团IIT', 'F-大财务部': '集团IIT',
    'F-账务部': '集团IIT', '公司费用-待结算&法人&智名': '集团IIT',
    'Shaun-客服部': '靠普', 'Shaun-外地': '靠普', 'Shaun-雇员服务部': '靠普',
    'HRO服务-公司销售部': '靠普', 'HRO服务-代收代付残疾人': '靠普',
    '园区-公寓&企业服务部': '公寓', '园区-商办&企业服务': '办公',
    'C-大后台-行政': '大后台', 'C-大后台-法务': '大后台', 'C-大后台-人事': '大后台',
    '老龙馄饨': '老龙', '物业管理部': '物业', '物业维修部': '物业',
    '物业保安部': '物业', '物业保洁部': '物业', '物业外包保安': '物业',
}

# ── 发薪公司 → 发薪公司系 映射表 ─────────
PAYROLL_TO_GROUP = {
    '开弈信息': '开弈人才系', '开弈中国': '开弈人才系', '开弈中国-美元': '开弈人才系',
    '开弈人才': '开弈人才系', '开弈人力资源': '开弈人才系', '开弈企业外包': '开弈人才系',
    '靠普人力': '开弈人才系', '开博人才': '开弈人才系', '弈享天津': '开弈人才系',
    '北京点才': '开弈人才系', '天津英才': '开弈人才系', '智名信息': '开弈人才系',
    '深圳和弈': '开弈人才系',
    '开弈投资': '开弈投资系', '弈工分信息': '开弈投资系', '弈工分健康': '开弈投资系',
    '弈工分健康（外包保安）': '开弈投资系', '人力资源研究院': '开弈投资系',
    '弈工分文化': '开弈投资系', '微芮洺': '开弈投资系', '时代人才': '开弈投资系',
    '老龙馄饨-灵工': '开弈投资系',
}

NUMERIC = [
    '企业人力成本总计', '实收', '基本工资', '考勤调整', '商保金额',
    'KPI预提', '本月工资', '商办佣金', '绩效', '公寓佣金',
    '防暑降温费', '津贴', '保安奖金', '保洁奖金', '薪资小计',
    '养老(个人)', '医疗(个人)', '失业(个人)', '公积金(个人)',
    '补充公积金(个人)', '个人福利合计', '当月个人所得税', '商保调整',
    '银行实发', '养老(公司)', '医疗(公司)', '失业(公司)', '工伤',
    '生育', '公积金(公司)', '补充公积金(公司)', '公司法定福利合计',
    '绩效&佣金合计', '预提福利费', '计税月份', '社保公积金缴纳月份',
]

_CHECK_MARKERS = ['验算', '合计', '核对']


def _clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """去除核对行，确保数字列正确"""
    clean = df.copy()

    # 去除姓名缺失或含核对标记的行
    mask_bad = (
        clean['姓名'].isna() |
        (clean['姓名'].astype(str).str.strip() == '') |
        clean['姓名'].astype(str).str.contains('|'.join(_CHECK_MARKERS), na=False)
    )
    clean = clean[~mask_bad]

    # 去除发薪公司验证数据为空的汇总行
    clean = clean.dropna(subset=['发薪公司验证数据'])
    clean = clean[~clean['发薪公司验证数据'].astype(str).str.contains(
        '|'.join(_CHECK_MARKERS), na=False)]
    clean = clean[clean['发薪公司验证数据'].astype(str).str.strip() != '']

    # 数字列转换
    for c in NUMERIC:
        if c in clean.columns:
            clean[c] = pd.to_numeric(clean[c], errors='coerce').fillna(0)

    return clean


def compute_summary(df: pd.DataFrame) -> dict:
    """从薪酬明细计算Summary"""

    # ── 1. 数据清洗 ──
    clean = _clean_data(df)

    present_num = [c for c in NUMERIC if c in clean.columns]

    # ── 2. 按发薪公司验证数据去重（同一个人跨公司合并）──
    dedup = clean.groupby('发薪公司验证数据', as_index=False).agg({
        **{c: 'sum' for c in present_num},
        '姓名': 'first',
        '成本中心（P&L核算标准）': 'first',
        '发薪公司': 'first',
        '部门': 'first',
        '人员性质': 'first',
    })

    # ── 3. 映射 ──
    dedup['板块'] = dedup['成本中心（P&L核算标准）'].map(CC_TO_BOARD).fillna('其他')
    dedup['发薪公司系'] = dedup['发薪公司'].map(PAYROLL_TO_GROUP).fillna('其他')

    # ── 4. 按板块聚合 ──
    by_board = (dedup.groupby('板块')
                .agg({**{c: 'sum' for c in present_num}, '姓名': 'count'})
                .rename(columns={'姓名': '人数'}).reset_index()
                .sort_values('企业人力成本总计', ascending=False))

    by_board_detail = (dedup.groupby(['板块', '成本中心（P&L核算标准）'])
                       .agg({**{c: 'sum' for c in present_num}, '姓名': 'count'})
                       .rename(columns={'姓名': '人数'}).reset_index()
                       .sort_values(['板块', '成本中心（P&L核算标准）']))

    # ── 5. 按发薪公司系聚合 ──
    by_payroll = (dedup.groupby('发薪公司系')
                  .agg({**{c: 'sum' for c in present_num}, '姓名': 'count'})
                  .rename(columns={'姓名': '人数'}).reset_index()
                  .sort_values('企业人力成本总计', ascending=False))

    by_payroll_detail = (dedup.groupby(['发薪公司系', '发薪公司'])
                         .agg({**{c: 'sum' for c in present_num}, '姓名': 'count'})
                         .rename(columns={'姓名': '人数'}).reset_index()
                         .sort_values(['发薪公司系', '发薪公司']))

    # ── 6. 总计 ──
    grand = {c: dedup[c].sum() for c in present_num}
    grand['人数'] = len(dedup)

    return {
        'by_board': by_board,
        'by_board_detail': by_board_detail,
        'by_payroll': by_payroll,
        'by_payroll_detail': by_payroll_detail,
        'grand_total': grand,
    }
