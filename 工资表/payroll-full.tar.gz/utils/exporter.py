"""导出模块 — Excel + PDF（含中文字体自动查找）"""

import io, os, subprocess
import pandas as pd
from fpdf import FPDF


def _find_cjk_font() -> str:
    candidates = [
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/google-noto-cjk/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc",
    ]
    for p in candidates:
        if os.path.exists(p):
            return p
    try:
        r = subprocess.run(['fc-list', ':lang=zh'], capture_output=True, text=True, timeout=5)
        if r.stdout.strip():
            path = r.stdout.strip().split('\n')[0].split(':')[0].strip()
            if os.path.exists(path):
                return path
    except:
        pass
    return ""


def _safe_str(s, maxlen=10):
    """转为纯 ASCII-safe 字符串，避免 unicode 错误"""
    try:
        return str(s).encode('ascii', errors='replace').decode('ascii')[:maxlen]
    except:
        return '?'


def export_to_excel(df: pd.DataFrame, sheet_name: str = "薪酬明细") -> bytes:
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
        df.to_excel(writer, sheet_name=sheet_name, index=False)
        wb = writer.book
        ws = writer.sheets[sheet_name]
        hdr_fmt = wb.add_format({
            'bold': True, 'bg_color': '#D32D26', 'font_color': '#FFFFFF',
            'border': 1, 'text_wrap': True, 'valign': 'vcenter',
        })
        for ci, cn in enumerate(df.columns):
            ws.write(0, ci, str(cn).replace('\n', ' ').strip(), hdr_fmt)
            ws.set_column(ci, ci, min(max(len(str(cn)), 2) + 2, 30))
    output.seek(0)
    return output.getvalue()


def export_summary_to_excel(by_board, by_payroll, grand_total: dict) -> bytes:
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
        by_board.to_excel(writer, sheet_name='按板块(BU)', index=False)
        by_payroll.to_excel(writer, sheet_name='按发薪公司系', index=False)
        pd.DataFrame([grand_total]).to_excel(writer, sheet_name='总计', index=False)
        fmt = writer.book.add_format({
            'bold': True, 'bg_color': '#D32D26', 'font_color': '#FFFFFF', 'border': 1,
        })
        for sn in ['按板块(BU)', '按发薪公司系', '总计']:
            ws = writer.sheets[sn]
            for ci in range(20):
                try:
                    orig = ws.cell_value(0, ci)
                    if orig is not None:
                        ws.write(0, ci, str(orig).replace('\n', ' ').strip(), fmt)
                except:
                    break
    output.seek(0)
    return output.getvalue()


def export_to_pdf(df: pd.DataFrame, title: str = "Payroll Report") -> bytes:
    font_path = _find_cjk_font()
    has_cjk = bool(font_path)

    from fpdf.enums import XPos, YPos
    pdf = FPDF(orientation='L', unit='mm', format='A3')
    pdf.add_page()

    # 标题（ASCII-safe）
    safe_title = _safe_str(title, 50)

    if has_cjk:
        pdf.add_font("CJK", "", font_path)
        pdf.add_font("CJK", "B", font_path)
        pdf.set_font("CJK", "B", 14)
    else:
        pdf.set_font("Helvetica", "B", 14)

    pdf.cell(0, 10, safe_title, new_x=XPos.LMARGIN, new_y=YPos.NEXT, align='C')
    pdf.ln(4)

    col_count = len(df.columns)
    usable_w = pdf.w - 10
    col_w = max(usable_w / col_count, 10)

    # 表头（ASCII-safe）
    if has_cjk:
        pdf.set_font("CJK", "B", 6)
        for c in df.columns:
            pdf.cell(col_w, 5, _safe_str(c, 8), border=1, align='C')
    else:
        pdf.set_font("Helvetica", "B", 6)
        for c in df.columns:
            pdf.cell(col_w, 5, _safe_str(c, 8), border=1, align='C')
    pdf.ln()

    # 数据行
    if has_cjk:
        pdf.set_font("CJK", "", 5)
    else:
        pdf.set_font("Helvetica", "", 5)

    for _, row in df.head(300).iterrows():
        for val in row:
            if pd.isna(val) or val == '' or val is None:
                txt = '-'
            elif isinstance(val, (int, float)):
                txt = f"{val:,.0f}" if abs(val) < 1e9 else f"{val:.0f}"
            else:
                txt = _safe_str(val, 10)
            pdf.cell(col_w, 4, txt, border=1, align='C')
        pdf.ln()

    return bytes(pdf.output())
