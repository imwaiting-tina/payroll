"""
认证模块 — HRO 开弈集团
"""

import streamlit as st
import hashlib
from typing import Optional

USERS = {
    "admin": {
        "password_hash": hashlib.sha256("admin123".encode()).hexdigest(),
        "role": "admin", "display_name": "管理员", "employee_name": None,
    },
    "hr": {
        "password_hash": hashlib.sha256("hr123".encode()).hexdigest(),
        "role": "hr", "display_name": "人事专员", "employee_name": None,
    },
    "employee": {
        "password_hash": hashlib.sha256("emp123".encode()).hexdigest(),
        "role": "employee", "display_name": "员工", "employee_name": "孟庆芳",
    },
}

FULL_ACCESS_ROLES = {"admin", "hr"}

STYLE = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
html,body,[class*="st-"]{font-family:'Inter',-apple-system,BlinkMacSystemFont,'PingFang SC','Microsoft YaHei',sans-serif}
.stApp{background:#F8F9FA}
[data-testid="stSidebar"]{background:#fff!important}
[data-testid="stSidebar"]>div:first-child{background:#fff!important;padding-top:1rem!important}
[data-testid="stSidebarNav"]{display:none!important}
div[data-testid="stElementToolbar"]{display:none!important}
#MainMenu,footer{display:none!important}
div[data-testid="stMetric"]{background:#fff;border:1px solid #E9E9E9;border-radius:10px;padding:16px 20px;box-shadow:0 1px 2px rgba(0,0,0,0.03)}
div[data-testid="stMetric"] label{color:#9CA3AF!important;font-weight:500;font-size:0.7rem}
div[data-testid="stMetric"] div[data-testid="stMetricValue"]{color:#595656!important;font-weight:700;font-size:1.3rem}
button[kind="primary"]{background:#D32D26!important;border:none!important;border-radius:8px!important;font-weight:600!important}
button[kind="primary"]:hover{background:#B71E1A!important}
.stDownloadButton button{border-radius:8px!important;font-weight:500!important}
div[data-testid="stDataFrame"]{border:1px solid #E9E9E9;border-radius:10px;overflow:hidden}
div[data-testid="stDataFrame"] th{background:#D32D26!important;color:#fff!important;font-weight:600;font-size:0.7rem;padding:8px 6px!important}
input[type="text"],input[type="password"]{border:1px solid #D4D3D3!important;border-radius:8px!important}
.stExpander{border:1px solid #E9E9E9;border-radius:10px}
hr{border-color:#E9E9E9!important;margin:18px 0!important}
button[data-testid="stBaseButton-header"]{display:none!important}
</style>
"""

LOGIN_OVERRIDE = """
<style>
[data-testid="stSidebar"]{display:none!important;width:0!important;min-width:0!important;max-width:0!important;overflow:hidden!important}
[data-testid="stSidebarNav"]{display:none!important}
</style>
"""


def inject_brand_css():
    st.markdown(STYLE, unsafe_allow_html=True)


def render_sidebar():
    inject_brand_css()
    if not st.session_state.authenticated:
        return

    with st.sidebar:
        st.markdown("""
        <div style="text-align:center;padding:8px 0 4px 0">
          <div style="font-size:1.4rem;font-weight:800;color:#D32D26;letter-spacing:-1px">HRO 开弈</div>
          <div style="font-size:0.6rem;color:#9CA3AF;letter-spacing:2px">PAYROLL SYSTEM</div>
        </div>
        """, unsafe_allow_html=True)
        st.divider()

        st.page_link("app.py", label="📊 总看板", icon="📊")
        st.page_link("pages/1_💼_Summary.py", label="💼 Summary", icon="💼")
        st.page_link("pages/2_💰_薪酬明细.py", label="💰 薪酬明细", icon="💰")

        st.divider()

        role = st.session_state.role
        display = st.session_state.get("display_name", "用户")
        st.markdown(f"""
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
          <div style="width:32px;height:32px;border-radius:50%;background:#D32D26;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:0.9rem">{display[0]}</div>
          <div>
            <div style="font-weight:600;font-size:0.85rem;color:#595656">{display}</div>
            <div style="font-size:0.65rem;color:#9CA3AF">{role}</div>
          </div>
        </div>
        """, unsafe_allow_html=True)

        if st.button("🚪 退出", key="logout", use_container_width=True):
            for k in list(st.session_state.keys()):
                del st.session_state[k]
            st.rerun()

        st.divider()
        st.caption("© 2026 HRO 开弈集团")


def verify_user(username: str, password: str) -> Optional[dict]:
    user = USERS.get(username)
    if user and user["password_hash"] == hashlib.sha256(password.encode()).hexdigest():
        return user
    return None


def check_login():
    if "authenticated" not in st.session_state:
        st.session_state.authenticated = False
        st.session_state.user = None
    if not st.session_state.authenticated:
        _render_login()
        st.stop()


def filter_data_by_role(df):
    role = st.session_state.get("role")
    if role in FULL_ACCESS_ROLES:
        return df
    if role == "employee":
        emp_name = st.session_state.user.get("employee_name")
        if emp_name and "姓名" in df.columns:
            return df[df["姓名"] == emp_name]
    return df.head(0)


def _render_login():
    st.markdown(STYLE + LOGIN_OVERRIDE, unsafe_allow_html=True)
    st.markdown("""
    <div style="height:10vh"></div>
    <div style="text-align:center">
      <div style="font-size:3rem;font-weight:800;color:#D32D26;letter-spacing:-2px">HRO</div>
      <div style="font-size:1.5rem;font-weight:300;color:#595656;margin-top:-4px">开弈集团</div>
      <div style="font-size:0.75rem;color:#9CA3AF;letter-spacing:3px;margin-top:6px">PAYROLL MANAGEMENT SYSTEM</div>
    </div>
    """, unsafe_allow_html=True)
    st.markdown("<br>", unsafe_allow_html=True)
    _, c, _ = st.columns([1, 1.2, 1])
    with c:
        with st.container(border=True):
            st.markdown('<div style="text-align:center;font-weight:600;color:#595656">登录</div>', unsafe_allow_html=True)
            u = st.text_input("用户名", placeholder="请输入用户名", key="login_user", label_visibility="collapsed")
            p = st.text_input("密码", placeholder="请输入密码", type="password", key="login_pwd", label_visibility="collapsed")
            if st.button("登 录", type="primary", use_container_width=True):
                user = verify_user(u, p)
                if user:
                    st.session_state.authenticated = True
                    st.session_state.user = user
                    st.session_state.username = u
                    st.session_state.role = user["role"]
                    st.session_state.display_name = user["display_name"]
                    st.rerun()
                else:
                    st.error("用户名或密码错误")
        st.markdown("""
        <div style="text-align:center;margin-top:16px">
          <span style="color:#9CA3AF;font-size:0.7rem">
            测试：admin / admin123 | hr / hr123 | employee / emp123
          </span>
        </div>
        """, unsafe_allow_html=True)
